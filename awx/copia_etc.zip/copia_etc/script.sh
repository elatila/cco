#script Estandares EAFIT
#1.2.1
yum repolist
#1.3.1

# 1.4.1
cp /boot/grub2/grub.cfg /boot/grub2/grub.cfg.ori
cp /oracle/copia_etc/grub.cfg /boot/grub2/
chown root:root /boot/grub2/grub.cfg  
chmod og-rwx /boot/grub2/grub.cfg 
#chown root:root /boot/grub2/user.cfg 
#chmod og-rwx /boot/grub2/user.cfg
echo "listo 1.4.1"

#1.6.2
yum install libselinux
echo "listo 1.6.2"

#1.7.2 despues de copiar el archivo gdm
dconf update

#2.2.1.1
yum install ntp
echo "ntp installed"
yum install chrony
echo "chrony installed"


#2.2.3
systemctl disable avahi-daemon
echo "listo 2.2.3"

# 2.2.4
systemctl disable cups
echo "listo 2.2.4"

#2.2.10
systemctl disable httpd
echo "listo 2.2.10"

# 2.2.7
systemctl disable nfs 
systemctl disable nfs-server 
systemctl disable rpcbind
echo "listo 2.2.7"

#2.3.4
yum remove telnet
echo "listo 2.3.4"
#3.1.1
sysctl -w net.ipv4.ip_forward=0 
sysctl -w net.ipv4.route.flush=1
echo "listo 3.1.1"
#3.5.1
#install dccp /bin/true
echo "listo 3.5.1"

#3.5.2
#install sctp /bin/true
echo "listo 3.5.2"

#4.1.2

systemctl is-enabled auditd
systemctl enable rsyslog
echo "listo 4.1.2"

#+++++++++++ FILES


########### CRONTAB ################ HACERLO AL FINAL m OK

#1.3.2
#crontab -u root -e
#0 5 * * * /usr/sbin/aide --check

                                                         chown root:root /etc/crontab
chmod og-rwx /etc/crontab
chown root:root /etc/cron.hourly 
chmod og-rwx /etc/cron.hourly
chown root:root /etc/cron.daily 
chmod og-rwx /etc/cron.daily
chown root:root /etc/cron.weekly 
chmod og-rwx /etc/cron.weekly
chown root:root /etc/cron.monthly 
chmod og-rwx /etc/cron.monthly
chown root:root /etc/cron.d 
chmod og-rwx /etc/cron.d
echo "listo crontab"

########### /etc/security/limits.conf ###############
#* hard core 0
#echo "listo limits"


########### /etc/sysctl.d/sysctl.conf ############




########## /etc/default/grub ################

cp /etc/default/grub /etc/default/grub.orig
cp /oracle/copia_etc/grub /etc/default/grub
grub2-mkconfig -o /boot/grub2/grub.cfg
grub2-mkconfig > /boot/grub2/grub.cfg

echo "grub"

########## /etc/selinux/config
cp /etc/selinux/config /etc/selinux/config.ori
cp /oracle/copia_etc/config /etc/selinux/config.ori
SELINUX=enforcing
SELINUXTYPE=targeted
echo "listo selinux"


############ 1.7.1.2  /etc/issue   
cp /etc/issue /etc/issue.orig
cp /oracle/copia_etc/issue /etc/issue
echo "listo issue"

############ 1.7.1.3  /etc/issue.net

cp /etc/issue.net /etc/issue.net.orig
cp /oracle/copia_etc/issue.net /etc/issue.net
echo "listo issue.net"

########### 3.1.2
cp /etc/sysctl.conf /etc/sysctl.conf.ori
cp /oracle/copia_etc/sysctl.conf /etc/sysctl.conf
echo "listo 3.1.2"


####### /etc/modprobe.d/CIS.conf

#cp /etc/modprobe.d/CIS.conf /etc/modprobe.d/CIS.conf.orig 
cp /oracle/copia_etc/CIS.conf /etc/modprobe.d/CIS.conf
echo "listo CIS.conf"


############ 4.1.1.1

cp /etc/audit/auditd.conf /etc/audit/auditd.conf.orig
cp /etc/audit/audit.rules /etc/audit/audit.rules.orig

cp /oracle/copia_etc/auditd.conf /etc/audit/auditd.conf
cp /oracle/copia_etc/audit.rules /etc/audit/audit.rules 
echo "listo 4.1.1.1 and 4.1.12"


######## 4.3
cp /etc/logrotate.conf  /etc/logrotate.conf.ori
cp /oracle/copia_etc/logrotate.conf /etc/logrotate.conf

echo "listo 4.3"



cp /etc/group /etc/group.ori
cp /oracle/copia_etc/group /etc/group

#########MODULO SSH

#5.2.1
sudo chown root:root /etc/ssh/sshd_config 
sudo chmod og-rwx /etc/ssh/sshd_config
sudo cp /etc/ssh/sshd_config /etc/ssh/sshd_config.ori
sudo cp /oracle/copia_etc/sshd_config /etc/ssh/sshd_config
echo "Listo SSH"

#5.3
cp /etc/security/pwquality.conf /etc/security/pwquality.conf.ori
cp /oracle/copia_etc/pwquality.conf /etc/security/pwquality.conf




#5.4
cp /etc/login.defs /etc/login.defs.ori
cp /oracle/copia_etc/login.defs /etc/login.defs
echo "listo 5.4"

usermod -s /sbin/nologin mysql
echo "listo 5.4.2."
useradd -D -f 30
chage --inactive 30 psoft
echo "listo user"


